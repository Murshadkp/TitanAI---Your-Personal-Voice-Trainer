
import React from 'react';
import { UserProfile, WorkoutSession } from '../types';
import TrainerHero from './TrainerHero';

interface DashboardProps {
  user: UserProfile;
  history: WorkoutSession[];
  onStartWorkout: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, history, onStartWorkout }) => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Welcome, {user.name}</h1>
          <p className="text-zinc-400">Your {user.goal} journey is on track.</p>
        </div>
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20">
          {user.name.charAt(0)}
        </div>
      </header>

      {/* Hero Illustration */}
      <TrainerHero />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Workouts', val: history.length, unit: '' },
          { label: 'Exercises', val: history.reduce((acc, s) => acc + s.exercises.length, 0), unit: '' },
          { label: 'Volume', val: '4.2k', unit: 'kg' },
          { label: 'Weight', val: user.weight, unit: 'kg' },
        ].map((stat, i) => (
          <div key={i} className="bg-zinc-900 border border-zinc-800 p-4 rounded-2xl hover:border-zinc-700 transition-colors">
            <p className="text-zinc-500 text-xs font-bold uppercase tracking-widest">{stat.label}</p>
            <p className="text-2xl font-black mt-1">{stat.val}<span className="text-sm font-normal text-zinc-500 ml-1">{stat.unit}</span></p>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 rounded-3xl shadow-xl shadow-blue-900/20 text-white relative overflow-hidden group">
        <div className="relative z-10">
          <h2 className="text-2xl font-bold mb-2">Ready to crush it?</h2>
          <p className="text-blue-100 mb-6 max-w-xs">Start your AI-guided voice session. Your trainer is waiting.</p>
          <button 
            onClick={onStartWorkout}
            className="bg-white text-blue-600 px-8 py-3 rounded-full font-bold hover:bg-blue-50 transition-all transform hover:scale-105 active:scale-95 flex items-center space-x-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M5.25 5.653c0-.856.917-1.398 1.667-.986l11.54 6.348a1.125 1.125 0 010 1.971l-11.54 6.347a1.125 1.125 0 01-1.667-.985V5.653z" />
            </svg>
            <span>Start Training</span>
          </button>
        </div>
        <div className="absolute top-0 right-0 p-8 text-blue-400 opacity-20 group-hover:scale-110 transition-transform duration-700">
           <svg className="w-48 h-48" fill="currentColor" viewBox="0 0 24 24"><path d="M20.57 14.86L22 13.43L20.57 12L17 15.57L8.43 7L12 3.43L10.57 2L9.14 3.43L7.71 2L6.28 3.43L4.86 2L3.43 3.43L2 2L.57 3.43L2 4.86L.57 6.28L2 7.71L.57 9.14L2 10.57L3.43 12L2 13.43L3.43 14.86L2 16.28L3.43 17.71L2 19.14L3.43 20.57L4.86 22L6.28 20.57L7.71 22L9.14 20.57L10.57 22L12 20.57L13.43 22L17 18.43l3.57-3.57zM5.29 17.29a1 1 0 0 1-1.42 0a1 1 0 0 1 0-1.42a1 1 0 0 1 1.42 1.42z"/></svg>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-bold mb-4">Activity Log</h3>
        {history.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed border-zinc-800 rounded-3xl">
            <p className="text-zinc-500">No workouts yet. Time to start your first session!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {history.map((session) => (
              <div key={session.id} className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 flex justify-between items-center">
                <div>
                  <p className="font-bold">{session.exercises.length} Exercises Completed</p>
                  <p className="text-xs text-zinc-500">{new Date(session.date).toLocaleDateString()}</p>
                </div>
                <div className="text-blue-500 font-bold">Details &rarr;</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
