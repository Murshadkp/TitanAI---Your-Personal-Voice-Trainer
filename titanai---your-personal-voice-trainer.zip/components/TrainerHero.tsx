
import React, { useEffect, useState } from 'react';
import { GoogleGenAI } from "@google/genai";

const TrainerHero: React.FC = () => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const generateIllustration = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const prompt = `A high-fidelity mobile UI mockup style illustration for a premium fitness app. 
        A fit individual wearing wireless earbuds in a dimly lit, high-end modern gym. 
        Cinematic lighting, soft focus on the background. 
        A prominent glowing blue holographic UI overlay in the foreground showing performance metrics like "18 Push-Ups" and a dynamic progress ring. 
        An abstract AI waveform pulsing at the bottom. 
        Minimalist, professional, athletic aesthetic with deep blacks and neon blue highlights. 
        Apple Fitness+ style polish and realistic depth.`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: [{ parts: [{ text: prompt }] }],
          config: {
            imageConfig: {
              aspectRatio: "16:9"
            }
          }
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
          if (part.inlineData) {
            setImageUrl(`data:image/png;base64,${part.inlineData.data}`);
            break;
          }
        }
      } catch (error) {
        console.error("Failed to generate hero image:", error);
      } finally {
        setLoading(false);
      }
    };

    generateIllustration();
  }, []);

  return (
    <div className="w-full relative h-48 md:h-64 overflow-hidden rounded-[32px] border border-zinc-800 bg-zinc-900 group shadow-2xl">
      {loading ? (
        <div className="w-full h-full animate-pulse bg-gradient-to-br from-zinc-800 to-zinc-900 flex items-center justify-center">
          <div className="flex flex-col items-center">
             <div className="w-12 h-12 border-4 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mb-3"></div>
             <span className="text-zinc-500 text-xs font-bold uppercase tracking-widest">Optimizing Performance...</span>
          </div>
        </div>
      ) : imageUrl ? (
        <>
          <img 
            src={imageUrl} 
            alt="AI Trainer Hero" 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
          <div className="absolute bottom-4 left-6">
            <span className="bg-blue-600/20 text-blue-400 text-[10px] font-black uppercase tracking-[0.2em] px-2 py-1 rounded-md border border-blue-500/30 backdrop-blur-md">
              Titan Protocol Active
            </span>
          </div>
        </>
      ) : (
        <div className="w-full h-full bg-zinc-900 flex items-center justify-center text-zinc-600 font-medium">
          Titan is ready for your session.
        </div>
      )}
    </div>
  );
};

export default TrainerHero;
