
import React, { useEffect, useState, useMemo } from 'react';
import { Exercise, WorkoutState, Difficulty } from '../types';

interface WorkoutSessionViewProps {
  state: WorkoutState;
  exercises: Exercise[];
  transcription: string;
  isModelSpeaking: boolean;
  onDifficultyChange: (difficulty: Difficulty) => void;
}

const WorkoutSessionView: React.FC<WorkoutSessionViewProps> = ({ state, exercises, transcription, isModelSpeaking, onDifficultyChange }) => {
  const currentEx = exercises[state.currentExerciseIndex];
  const [waveform, setWaveform] = useState<number[]>(new Array(20).fill(4));
  
  // Animation for the AI waveform
  useEffect(() => {
    let interval: number;
    if (isModelSpeaking) {
      interval = window.setInterval(() => {
        setWaveform(prev => prev.map(() => Math.floor(Math.random() * 40) + 10));
      }, 80);
    } else {
      interval = window.setInterval(() => {
        setWaveform(prev => prev.map(() => Math.floor(Math.random() * 8) + 4));
      }, 150);
    }
    return () => clearInterval(interval);
  }, [isModelSpeaking]);

  if (!currentEx) return null;

  // Calculate set progress
  const setProgress = (state.currentSet / currentEx.targetSets) * 100;
  
  return (
    <div className="flex flex-col h-full bg-black text-white relative select-none">
      {/* Background Micro-Overlays / Feedback */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10">
        <div className={`w-[120%] aspect-square rounded-full border border-blue-500/30 ${isModelSpeaking ? 'animate-pulse' : 'animate-pulse-slow'}`}></div>
      </div>

      {/* Header Info - De-emphasized */}
      <div className="z-10 flex justify-between items-center px-2 mb-12">
        <div className="flex flex-col">
          <span className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Up Next</span>
          <span className="text-zinc-300 font-bold text-sm">
            {exercises[state.currentExerciseIndex + 1]?.name || 'Cooldown'}
          </span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-zinc-500 text-[10px] font-black uppercase tracking-[0.2em] mb-1">Volume</span>
          <span className="text-zinc-300 font-bold text-sm">{state.currentSet * currentEx.targetReps} reps</span>
        </div>
      </div>

      {/* Main Action Area */}
      <div className="flex-1 flex flex-col items-center justify-center z-10 space-y-12">
        <div className="relative flex items-center justify-center">
          {/* Progress Ring */}
          <svg className="w-72 h-72 transform -rotate-90">
            <circle
              cx="144"
              cy="144"
              r="130"
              stroke="currentColor"
              strokeWidth="4"
              fill="transparent"
              className="text-zinc-900"
            />
            <circle
              cx="144"
              cy="144"
              r="130"
              stroke="currentColor"
              strokeWidth="8"
              fill="transparent"
              strokeDasharray={2 * Math.PI * 130}
              strokeDashoffset={2 * Math.PI * 130 * (1 - setProgress / 100)}
              className="text-blue-500 transition-all duration-1000 ease-out shadow-[0_0_15px_rgba(59,130,246,0.5)]"
              strokeLinecap="round"
            />
          </svg>

          {/* Center Text */}
          <div className="absolute flex flex-col items-center text-center">
            <h1 className="text-5xl font-black tracking-tighter mb-2 animate-in fade-in slide-in-from-bottom-2">
              {currentEx.targetReps}
            </h1>
            <p className="text-zinc-500 font-bold uppercase tracking-[0.2em] text-xs">
              {currentEx.name}
            </p>
            <div className="mt-4 bg-zinc-900/50 px-3 py-1 rounded-full border border-zinc-800 backdrop-blur-sm">
              <span className="text-blue-400 font-black text-[10px] uppercase">Set {state.currentSet} of {currentEx.targetSets}</span>
            </div>
          </div>
        </div>

        {/* Dynamic Waveform Orb */}
        <div className="flex items-center space-x-1 h-12">
          {waveform.map((h, i) => (
            <div
              key={i}
              className={`w-1 rounded-full bg-blue-500 transition-all duration-150 ${isModelSpeaking ? 'opacity-100' : 'opacity-40'}`}
              style={{ height: `${h}%` }}
            />
          ))}
        </div>
      </div>

      {/* Footer Interface */}
      <div className="z-10 space-y-6">
        {/* Transcription - Non-blocking overlay style */}
        <div className="h-16 flex items-center justify-center text-center px-4">
          <p className="text-zinc-400 font-medium italic text-sm transition-opacity duration-300">
            {transcription || "Listening for 'Next Set' or 'Too Hard'..."}
          </p>
        </div>

        {/* Quick Difficulty - Subtle interaction */}
        <div className="grid grid-cols-3 gap-2 bg-zinc-900/30 p-1 rounded-2xl border border-zinc-800/50">
          {Object.values(Difficulty).map((level) => (
            <button
              key={level}
              onClick={() => onDifficultyChange(level)}
              className={`py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${
                currentEx.difficulty === level 
                  ? 'bg-blue-600 text-white shadow-[0_0_20px_rgba(59,130,246,0.3)] scale-100' 
                  : 'text-zinc-600 hover:text-zinc-400 scale-95'
              }`}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Rest Timer Overlay */}
      {state.isResting && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-xl z-50 flex flex-col items-center justify-center animate-in fade-in duration-500">
          <span className="text-zinc-500 font-black uppercase tracking-[0.3em] mb-4 text-xs">Resting</span>
          <div className="text-[120px] font-black tracking-tighter text-blue-500 tabular-nums">
            {state.timer}
          </div>
          <p className="text-zinc-400 font-bold mt-4">Stay focused. Breathe.</p>
        </div>
      )}
    </div>
  );
};

export default WorkoutSessionView;
