
import React, { useState } from 'react';
import { UserProfile, FitnessGoal, ExperienceLevel, CoachStyle } from '../types';

interface OnboardingProps {
  onComplete: (profile: UserProfile) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    age: 25,
    weight: 70,
    height: 175,
    goal: FitnessGoal.STRENGTH,
    experience: ExperienceLevel.BEGINNER,
    coachStyle: CoachStyle.FRIENDLY,
  });

  const next = () => setStep(s => s + 1);

  return (
    <div className="max-w-md mx-auto h-full flex flex-col justify-center animate-in fade-in zoom-in duration-500">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-500">TitanAI</h1>
        <p className="text-zinc-400 font-medium">Step {step} of 3</p>
      </div>

      <div className="bg-zinc-900 p-8 rounded-[40px] border border-zinc-800 shadow-2xl">
        {step === 1 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">What's your name?</h2>
            <input 
              type="text" 
              placeholder="e.g. Alex"
              className="w-full bg-zinc-800 border border-zinc-700 rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-xl"
              value={profile.name}
              onChange={e => setProfile({...profile, name: e.target.value})}
            />
            <button 
              disabled={!profile.name}
              onClick={next}
              className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-blue-500/20"
            >
              Continue
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Physical Stats</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-zinc-500 font-bold uppercase mb-1 block">Weight (kg)</label>
                <input 
                  type="number" 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-2xl p-4 outline-none text-xl"
                  value={profile.weight}
                  onChange={e => setProfile({...profile, weight: parseInt(e.target.value)})}
                />
              </div>
              <div>
                <label className="text-xs text-zinc-500 font-bold uppercase mb-1 block">Height (cm)</label>
                <input 
                  type="number" 
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-2xl p-4 outline-none text-xl"
                  value={profile.height}
                  onChange={e => setProfile({...profile, height: parseInt(e.target.value)})}
                />
              </div>
            </div>
            <button 
              onClick={next}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-2xl transition-all"
            >
              Almost there
            </button>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Trainer Preference</h2>
            <div className="space-y-2">
              {Object.values(CoachStyle).map(style => (
                <button
                  key={style}
                  onClick={() => setProfile({...profile, coachStyle: style})}
                  className={`w-full p-4 rounded-2xl border transition-all text-left ${profile.coachStyle === style ? 'bg-blue-600/20 border-blue-500 text-blue-100' : 'bg-zinc-800 border-zinc-700 text-zinc-400'}`}
                >
                  <span className="font-bold">{style}</span>
                </button>
              ))}
            </div>
            <button 
              onClick={() => onComplete(profile)}
              className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-blue-500/20"
            >
              Start Training
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Onboarding;
