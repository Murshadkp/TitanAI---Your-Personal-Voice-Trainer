
import { Exercise, ExperienceLevel, FitnessGoal, Difficulty } from '../types';

export const EXERCISES: Exercise[] = [
  { id: '1', name: 'Push-Ups', muscleGroup: 'Chest', description: 'Standard push-ups.', targetReps: 12, targetSets: 3, restSeconds: 60, difficulty: Difficulty.MEDIUM },
  { id: '2', name: 'Bodyweight Squats', muscleGroup: 'Legs', description: 'Air squats.', targetReps: 15, targetSets: 3, restSeconds: 60, difficulty: Difficulty.MEDIUM },
  { id: '3', name: 'Plank', muscleGroup: 'Core', description: 'Standard elbow plank.', targetReps: 1, targetSets: 3, restSeconds: 30, difficulty: Difficulty.MEDIUM },
  { id: '4', name: 'Lunges', muscleGroup: 'Legs', description: 'Walking or stationary lunges.', targetReps: 10, targetSets: 3, restSeconds: 60, difficulty: Difficulty.MEDIUM },
  { id: '5', name: 'Mountain Climbers', muscleGroup: 'Core', description: 'Fast mountain climbers.', targetReps: 20, targetSets: 3, restSeconds: 45, difficulty: Difficulty.MEDIUM },
];

export function adjustExerciseByDifficulty(exercise: Exercise, difficulty: Difficulty): Exercise {
  const base = EXERCISES.find(ex => ex.id === exercise.id) || exercise;
  
  switch (difficulty) {
    case Difficulty.EASY:
      return {
        ...base,
        difficulty,
        targetReps: Math.max(1, Math.floor(base.targetReps * 0.7)),
        targetSets: Math.max(1, base.targetSets - 1),
        restSeconds: Math.floor(base.restSeconds * 1.3),
      };
    case Difficulty.HARD:
      return {
        ...base,
        difficulty,
        targetReps: Math.floor(base.targetReps * 1.5),
        targetSets: base.targetSets + 1,
        restSeconds: Math.floor(base.restSeconds * 0.8),
      };
    case Difficulty.MEDIUM:
    default:
      return { ...base, difficulty: Difficulty.MEDIUM };
  }
}

export function getRecommendedWorkout(goal: FitnessGoal, experience: ExperienceLevel): Exercise[] {
  if (experience === ExperienceLevel.BEGINNER) {
    return EXERCISES.slice(0, 3).map(ex => adjustExerciseByDifficulty(ex, Difficulty.MEDIUM));
  }
  return EXERCISES.map(ex => adjustExerciseByDifficulty(ex, Difficulty.MEDIUM));
}
